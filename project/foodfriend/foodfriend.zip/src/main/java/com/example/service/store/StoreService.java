package com.example.service.store;

public interface StoreService {
	
	public void delete(String s_code);

}
